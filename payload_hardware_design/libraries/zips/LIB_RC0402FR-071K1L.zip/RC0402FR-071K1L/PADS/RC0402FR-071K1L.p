*PADS-LIBRARY-PART-TYPES-V9*

RC0402FR-071K1L RESC1005X40N I RES 7 1 0 0 0
TIMESTAMP 2026.05.11.14.12.22
"Mouser Part Number" 603-RC0402FR-071K1L
"Mouser Price/Stock" https://www.mouser.com/Search/Refine.aspx?Keyword=603-RC0402FR-071K1L
"Manufacturer_Name" Yageo Group
"Manufacturer_Part_Number" RC0402FR-071K1L
"Description" RESISTOR, 0402 1.1K Ohms +/-1% 1/16 W
"Datasheet Link" http://www.mouser.com/datasheet/2/447/PYu-RC_Group_51_RoHS_L_10-1527934.pdf
"Geometry.Height" 0.4mm
GATE 1 2 0
RC0402FR-071K1L
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
603764/1743273/2.50/2/0/Resistor
