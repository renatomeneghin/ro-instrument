*PADS-LIBRARY-PART-TYPES-V9*

RC0402FR-0715KL RESC1005X40N I RES 7 1 0 0 0
TIMESTAMP 2026.05.11.14.01.55
"Mouser Part Number" 603-RC0402FR-0715KL
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Yageo/RC0402FR-0715KL?qs=V1yeUXFNrkkV0Qg60g4JvA%3D%3D
"Manufacturer_Name" Yageo Group
"Manufacturer_Part_Number" RC0402FR-0715KL
"Description" Res SMD 0402 15K 1% 0.0625W T.C.100ppm Yageo RC Series Thick Film Surface Mount Resistor 0402 Case 15k +/-1% 0.063W +/-100ppm/C
"Datasheet Link" http://www.yageo.com/documents/recent/PYu-RC0402_51_RoHS_L_6_r.pdf
"Geometry.Height" 0.4mm
GATE 1 2 0
RC0402FR-0715KL
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
321320/1743273/2.50/2/5/Resistor
